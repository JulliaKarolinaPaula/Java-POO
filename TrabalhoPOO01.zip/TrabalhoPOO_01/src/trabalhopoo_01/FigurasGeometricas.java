package trabalhopoo_01;

/**
 *TRABALHO GETTERS - SETTERS
 * @author Jullia Karolina
 */
public class FigurasGeometricas {
        private double lado, altura, base, baseMaior, baseMenor;
        private String nomeFigura;

        public FigurasGeometricas(double lado, double altura, double base, double baseMaior, double baseMenor, String nomeFigura) {
            this.lado = lado;
            this.altura = altura;
            this.base = base;
            this.baseMaior = baseMaior;
            this.baseMenor = baseMenor;
            this.nomeFigura = nomeFigura;
        }
        
        public FigurasGeometricas() {}

        public double getLado() {
            return lado;
        }

        public void setLado(double lado) {
            if(lado <= 0){
                this.lado = 1;
            } else {
                this.lado = lado;
            }
        }

        public double getAltura() {
            return altura;
        }

        public void setAltura(double altura) {
            if(altura <= 0){
                this.altura = 1;
            } else {
                this.altura = altura;
            }
        }

        public double getBase() {
            return base;
        }

        public void setBase(double base) {
            if(base <= 0){
                this.base = 1;
            } else {
                this.base = base;
            }
        }

        public double getBaseMaior() {
            return baseMaior;
        }

        public void setBaseMaior(double baseMaior) {
            if(baseMaior <= 0){
                this.baseMaior= 1;
            } else {
                this.baseMaior = baseMaior;
            }
        }

        public double getBaseMenor() {
            return baseMenor;
        }

        public void setBaseMenor(double baseMenor) {
            if(baseMenor <= 0){
                this.baseMenor= 1;
            } else {
                this.baseMenor = baseMenor;
            }
        }

        public String getNomeFigura() {
            return nomeFigura;
        }

        public void setNomeFigura(String nomeFigura) {
            this.nomeFigura = nomeFigura;
        }
        
        public double calcularAreaFigura(){
            double area;
            if(this.getNomeFigura().equalsIgnoreCase("Quadrado")){
                area = this.getLado() * this.getLado();
            } else  if(this.getNomeFigura().equalsIgnoreCase("Triangulo")){
                area = (this.getBase() * this.getAltura()) / 2;
            }  else if(this.getNomeFigura().equalsIgnoreCase("Trapezio")){
                area = ((this.getBaseMaior() + this.getBaseMenor()) * this.getAltura()) / 2;
            } else{
                area = 0.0;
            }
                return area;
        }
        
        public void imprimir(){
            System.out.println();
            System.out.println("Nome da figura: "+this.getNomeFigura()+"\nArea: "+calcularAreaFigura()+"\nLado: "+this.getLado()+"\nAltura: "+this.getAltura()+"\nBase: "+this.getBase()+"\nBase Maior: "+this.getBaseMaior()+"\nBase Menor: "+this.getBaseMenor());
        }
        
        
    
    
        
        
}
