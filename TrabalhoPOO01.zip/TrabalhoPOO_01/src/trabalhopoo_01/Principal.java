package trabalhopoo_01;

/**
 *TRABALHO GETTERS - SETTERS
 * @author Jullia Karolina 
 */
public class Principal {
    public static void main(String[] args) {
        FigurasGeometricas qua = new FigurasGeometricas();
            qua.setNomeFigura("Quadrado");
            qua.setLado(5.0);
            qua.setAltura(5.0);
            qua.setBase(5.0);
            qua.setBaseMaior(5.0);
            qua.setBaseMenor(5.0);
            qua.imprimir();
            
        FigurasGeometricas tri = new FigurasGeometricas();
            tri.setNomeFigura("Triangulo");
            tri.setLado(3.0);
            tri.setAltura(5.0);
            tri.setBase(0);
            tri.setBaseMaior(2.0);
            tri.setBaseMenor(0);
            tri.imprimir();
            
        FigurasGeometricas tra = new FigurasGeometricas();
            tra.setNomeFigura("Trapezio");
            tra.setLado(-4.5);
            tra.setAltura(4.5);
            tra.setBase(0);
            tra.setBaseMaior(3.5);
            tra.setBaseMenor(2.0);
            tra.imprimir();
          
          FigurasGeometricas los = new FigurasGeometricas();
            los.setNomeFigura("Losango");
            los.setLado(2.5);
            los.setAltura(3.6);
            los.setBase(0);
            los.setBaseMaior(4.4);
            los.setBaseMenor(3.3);
            los.imprimir();
    }
    
}
