package trabalhopoo_02;

/**
 *TRABALHO GETTERS - SETTERS
 * @author Jullia Karolina
 */
public class Consulta {
          private String nomePaciente, dataNascimento, profissao;
          private boolean convenio;

          public Consulta() {}

          public Consulta(String nomePaciente, String dataNascimento) {
//           Nome do Paciente
               if(nomePaciente.equals(" ")){
                    this.nomePaciente = "Sem preenchimento";
              }else{
                    this.nomePaciente = nomePaciente;
              }
//          Data de Nascimento
              if(dataNascimento.equals(" ")){
                    this.dataNascimento = "Sem preenchimento";
               }else{
                    this.dataNascimento = dataNascimento;
               }
              
          }

          public String getNomePaciente() {
               return nomePaciente;
          }

          public void setNomePaciente(String nomePaciente) {
              if(nomePaciente.equals(" ")){
                    this.nomePaciente = "Sem preenchimento";
              }else{
                    this.nomePaciente = nomePaciente;
              }
               
          }

          public String getDataNascimento() {
               return dataNascimento;
          }

          public void setDataNascimento(String dataNascimento) {
               if(dataNascimento.equals(" ")){
                    this.dataNascimento = "Sem preenchimento";
               }else{
                    this.dataNascimento = dataNascimento;
               }
          }

          public String getProfissao() {
               return profissao;
          }

          public void setProfissao(String profissao) {
               this.profissao = profissao;
          }

          public String  getConvenio() {
                if(this.convenio == true){
                    return("Sim");
                }else{
                    return("Nao");
                } 
          }

          public void setConvenio(boolean convenio) {
               this.convenio = convenio;
          }
          
          public void imprimir(){
                System.out.println();
                System.out.println("Nome do Paciente: "+this.getNomePaciente());
                System.out.println("Data de Nascimento: "+this.getDataNascimento());
                System.out.println("Profissao: "+this.getProfissao());
                System.out.println("Possui convenio: "+this.getConvenio());
          }
}
