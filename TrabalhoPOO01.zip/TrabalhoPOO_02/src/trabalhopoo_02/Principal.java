package trabalhopoo_02;

/**
 * TRABALHO GETTERS - SETTERS
 * @author Jullia Karolina
 */
public class Principal {
    public static void main(String[] args) {
          /*VIA CONSTRUTOR VAZIO*/
           Consulta a = new Consulta();
                a.setNomePaciente("Jose Maria");
                a.setDataNascimento(" ");
                a.setProfissao("Mecanico");
                a.setConvenio(true);
                a.imprimir();
   
            Consulta b = new Consulta();
                b.setNomePaciente("Maria Jose");
                b.setDataNascimento("0/0/0");
                b.setProfissao("Do Lar");
                b.setConvenio(false);
                b.imprimir();
          
          /*VIA CONSTRUTOR SOBRECARREGADO*/
            Consulta c = new Consulta(" ", "21/08/1964");
               c.setProfissao("Marceneiro");
               c.setConvenio(false);
               c.imprimir();
               
             Consulta d = new Consulta("Marcia F."," ");
               d.setProfissao("Aux. Administrativo");
               d.setConvenio(true);
               d.imprimir();

    }
    
}
