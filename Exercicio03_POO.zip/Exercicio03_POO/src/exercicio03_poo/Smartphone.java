package exercicio03_poo;

/**
 *
 * @author Jullia Karolina
 * Data da aula: 07/10/2024
 */
public class Smartphone {
    private String modelo, marca;
    private int memoriaRam, hd;
    
    public Smartphone(String modelo, String marca, int memoriaRam, int hd) {
        this.modelo = modelo;
        this.marca = marca;
        this.memoriaRam = memoriaRam;
        this.hd = hd;
    }
    
    public Smartphone(){}
    
    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
       if((marca.equals("Apple"))||(marca.equals("Sansung"))||(marca.equals("Xiaomi"))){
          this.marca = marca;
       } else{
          this.marca = "Marca nao aceita.";
        }
    }

    public int getMemoriaRam() {
        return memoriaRam;
    }

    public void setMemoriaRam(int memoriaRam) {
        if(memoriaRam <= 0){
           this.memoriaRam = 2048;
        } else {
            this.memoriaRam = memoriaRam;
        }   
    }

    public int getHd() {
        return hd;
    }

    public void setHd(int hd) {
        this.hd = hd;
    }
    
    public void imprimirInformacaoes(){
        System.out.println();
        System.out.println("Marca: "+this.getMarca());
        System.out.println("Modelo: "+this.getModelo());
        System.out.println("Memoria Ram: "+ this.getMemoriaRam());
        System.out.println("HD: "+ this.getHd());
    }
}
