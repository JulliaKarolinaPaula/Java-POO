package exercicio03_poo;

/**
 *
 * @author Jullia Karolina 
 * Data da aula: 07/10/2024
 */
public class Principal {
    public static void main(String[] args) {
       Smartphone s1 = new Smartphone ("Galaxy S24 Ultra", "Sansung", 8192, 1000);
       
       s1.imprimirInformacaoes();
       
       
       Smartphone s2 = new Smartphone("Iphone 16", "Apple",-8192,1000);
       
       s2.imprimirInformacaoes();
       
       Smartphone s3 = new Smartphone();
       
       s3.setMarca("Motorola");
       s3.setModelo("Moto G5");
       s3.setMemoriaRam(0);
       s3.setHd(250);
       s3.imprimirInformacaoes();
    }
    
}
