package exercicioheranca;

/**
 *
 * @author Jullia Karolina
 */
public class Professor extends UsuarioSistema{
    private int siape;
    private String nucleo;

    public Professor(int siape, String nucleo, String nome, String login, String email, int senha) {
      super(nome, login, email, senha);
        this.siape = siape;
        if((nucleo.equalsIgnoreCase("Informatica"))||(nucleo.equalsIgnoreCase("Eletrica"))||(nucleo.equalsIgnoreCase("Administracao"))){
            this.nucleo = nucleo;
        }else{
            this.nucleo = "Nao Informado";
        }
    }

    public int getSiape() {
        return siape;
    }

    public void setSiape(int siape) {
        this.siape = siape;
    }

    public String getNucleo() {
        return nucleo;
    }

    public void setNucleo(String nucleo) {
        this.nucleo = nucleo;
    }
    
    @Override
    
    public String mostrarInformacoes(){
        System.out.println(super.mostrarInformacoes());
        
        return "\nPROFESSOR"+"\nSiape: "+this.getSiape()+"\nNucleo: "+this.getNucleo();
    }
}
