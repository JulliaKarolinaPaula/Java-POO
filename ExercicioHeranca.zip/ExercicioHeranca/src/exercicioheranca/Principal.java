package exercicioheranca;

/**
 *
 * @author Jullia Karolina
 */
public class Principal {
    public static void main(String[] args) {
       Coordenador c = new Coordenador("ANALISE E DESENVOLVIMENTO DE SISTEMAS", 1564789, "Ligia"," ","ligia@iftm.br",1267);
       System.out.println(c.mostrarInformacoes());
       
       Professor p = new Professor(789562, "Informatica","Lucas","lucasProfessor","lucas@iftm.br",0);
       System.out.println(p.mostrarInformacoes());
       
       Professor p1 = new Professor(1597543,"Contabil","Wesley","wesleyProfessor","wesley@iftm.br",321);
       System.out.println(p1.mostrarInformacoes());
       
       Aluno a = new Aluno(1134789,"POO, Engenharia de Software II","Jullia","jkpaula","jullia@iftm.br",147963);
       System.out.println(a.mostrarInformacoes());
    }
    
}
