package exercicioheranca;

/**
 *
 * @author Jullia Karolina
 */
public class Coordenador extends UsuarioSistema{
    private String curso;
    private int senhaMplan;

    public Coordenador(String curso, int senhaMplan, String nome, String login, String email, int senha) {
        super(nome, login, email, senha);
        this.curso = curso;
        this.senhaMplan = senhaMplan;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public int getSenhaMplan() {
        return senhaMplan;
    }

    public void setSenhaMplan(int senhaMplan) {
        this.senhaMplan = senhaMplan;
    }
    
    @Override
    
    public String mostrarInformacoes(){
        System.out.println(super.mostrarInformacoes());
        
        return "\nCOORDENADOR"+"\nCurso: "+this.getCurso()+"\nSenha Mplan: "+this.getSenhaMplan();
    }
}
