package exercicioheranca;

/**
 *
 * @author Jullia Karolina
 */
public abstract class UsuarioSistema {
    private String nome, login, email;
    private int senha;

    public UsuarioSistema(String nome, String login, String email, int senha) {
        this.nome = nome;
        this.email = email;
            if(login.equals(" ")){
                this.login = "admin";
            }else{
                this.login = login;
            }
        
            if(senha == 0){
                this.senha = 123;
            }else{
                this.senha = senha;
            }
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getSenha() {
        return senha;
    }

    public void setSenha(int senha) {
        this.senha = senha;
    }
    
    public String mostrarInformacoes(){
      return "\nNome: "+this.getNome()+"\nLogin: "+this.getLogin()+"\nSenha: "+this.getSenha()+"\nEmail: "+this.getEmail();
    }
    
}
