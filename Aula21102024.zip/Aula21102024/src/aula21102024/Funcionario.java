package aula21102024;

/**
 * Data: 21/10/2024
 * @author Jullia Karolina
 */
public class Funcionario {
    private String primeiroNome, segundoNome;
    private double salario; 

    public Funcionario(String primeiroNome, String segundoNome, double salario) {
        this.primeiroNome = primeiroNome;
        this.segundoNome = segundoNome;
        this.salario = salario;
    }

    public String getPrimeiroNome() {
        return primeiroNome;
    }

    public void setPrimeiroNome(String primeiroNome) {
        this.primeiroNome = primeiroNome;
    }

    public String getSegundoNome() {
        return segundoNome;
    }

    public void setSegundoNome(String segundoNome) {
        this.segundoNome = segundoNome;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }
    
    public void imprimir(){
        System.out.println("\n1o Nome: "+this.getPrimeiroNome());
        System.out.println("2o Nome: "+this.getSegundoNome());
        System.out.println("Salario Base: R$ "+this.getSalario());
    } 
}
