package aula21102024;

/**
 * Data: 21/10/2024
 * @author Jullia Karolina
 */
public class FuncionarioComissionado extends Funcionario {
    private double comissao, salarioComissionado;
    private int vendas;

    public FuncionarioComissionado(double comissao, double salarioComissionado, int vendas, String primeiroNome, String segundoNome, double salario) {
        super(primeiroNome, segundoNome, salario);
        this.comissao = comissao;
        this.salarioComissionado = salarioComissionado;
        this.vendas = vendas;
    }

    public double getComissao() {
        return comissao;
    }

    public void setComissao(double comissao) {
        this.comissao = comissao;
    }

    public double getSalarioComissionado() {
        return salarioComissionado;
    }

    public void setSalarioComissionado(double salarioComissionado) {
        this.salarioComissionado = salarioComissionado;
    }

    public int getVendas() {
        return vendas;
    }

    public void setVendas(int vendas) {
        this.vendas = vendas;
    }
    
    public void adicionarVendas(int vendas){
        this.setVendas(this.getVendas() + vendas);
    }
    public void calcularSalarioComissionado(){
        double sal;
       
        sal = (this.getComissao()*this.getVendas()) + super.getSalario();
        
        this.setSalarioComissionado(sal);
    }
    public void removerVendas(int vendas){
        this.setVendas(this.getVendas() - vendas);
    }
    
    @Override
    
    public void imprimir(){
        this.calcularSalarioComissionado();
        super.imprimir();
        System.out.println("Comissao: R$"+this.getComissao());
        System.out.println("Vendas: "+this.getVendas());
        System.out.println("Salario Comissionado: R$ "+this.getSalarioComissionado());
    }
}
