package aula21102024;

/**
 * Data: 21/10/2024
 * @author Jullia Karolina
 */
public class Principal {
    public static void main(String[] args) {
       Funcionario j = new Funcionario("Joao", "Pires", 900.00);
       j.imprimir();
       
       FuncionarioComissionado m = new FuncionarioComissionado(20.50,0.0,25,"Maria", "Batista", 1500.00);
       m.imprimir();
       m.adicionarVendas(2);
       m.imprimir();
       m.removerVendas(7);
       m.imprimir();
    }
    
}
